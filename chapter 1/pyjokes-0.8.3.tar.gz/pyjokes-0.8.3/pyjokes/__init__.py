from .pyjokes import get_joke, get_jokes, forever, LANGUAGE_VALUES, CATEGORY_VALUES
